select * from vendors INNER JOIN invoices on vendors.vendor_id=invoices.vendor_id;

select v.vendor_name, i.invoice_number, i.invoice_date, 
i.invoice_total-i.payment_total-i.credit_total as balance_due from vendors v,invoices i
where v.vendor_id=i.vendor_id and i.invoice_total-i.payment_total-i.credit_total!=0
ORDER BY vendor_name desc;

select vendor_name, default_account_number, account_description as description from vendors v join general_ledger_accounts g
where g.account_number=v.default_account_number
ORDER BY account_description, vendor_name;

select vendor_name,invoice_date,invoice_number,invoice_sequence as li_sequence,line_item_amount as li_amount
from (vendors v JOIN invoices i on v.vendor_id=i.vendor_id) join invoice_line_items i2 on i2.invoice_id=i.invoice_id
ORDER BY vendor_name, invoice_date, invoice_number, invoice_sequence;  

select v1.vendor_id, v1.vendor_name, CONCAT(v1.vendor_contact_first_name,v1.vendor_contact_last_name) from vendors v1, vendors v2
where v1.vendor_contact_last_name=v2.vendor_contact_last_name and v1.vendor_id!=v2.vendor_id;

select ge.account_number, ge.account_description, inv.invoice_id 
from general_ledger_accounts ge LEFT OUTER JOIN invoice_line_items inv on ge.account_number=inv.account_number
where inv.invoice_id is null;

select vendor_name,'Outside CA' from vendors where vendor_state!='CA' UNION
select vendor_name,'CA' from vendors where vendor_state='CA'
ORDER BY vendor_name; 