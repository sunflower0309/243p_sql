select DISTINCT vendor_name from vendors where vendor_id in
(select DISTINCT vendor_id from invoices) ORDER BY vendor_name;

select invoice_number,invoice_total from invoices 
where payment_total>(SELECT AVG(payment_total) from invoices where payment_total>0) ORDER BY invoice_total DESC;

select account_number, account_description from general_ledger_accounts
where not EXISTS (SELECT invoice_line_items.account_number from invoice_line_items
where invoice_line_items.account_number=general_ledger_accounts.account_number)
order by account_number;

-- select account_number, account_description from general_ledger_accounts
-- where account_number not in (SELECT DISTINCT account_number from invoice_line_items) order by account_number;
select v.vendor_name, li.invoice_id,li.invoice_sequence,li.line_item_amount FROM invoices i join vendors v
on i.vendor_id=v.vendor_id
join invoice_line_items li 
on li.invoice_id=i.invoice_id
where li.invoice_id in (SELECT DISTINCT invoice_id from invoice_line_items where invoice_sequence>1)
ORDER BY vendor_name, i.invoice_id, invoice_sequence;

select sum(max) FROM
(select vendor_id, max(invoice_total) as max from invoices where payment_total=0
GROUP BY vendor_id) as v2;

SELECT vendor_name, vendor_city, vendor_state
FROM vendors
WHERE CONCAT(vendor_state, vendor_city) NOT IN 
(SELECT CONCAT(vendor_state, vendor_city) as vendor_city_state
FROM vendors GROUP BY vendor_city_state HAVING COUNT(*) > 1)
ORDER BY vendor_state, vendor_city;

select vendor_name,invoice_number,invoice_date,invoice_total from invoices i join vendors v
on i.vendor_id=v.vendor_id 
where invoice_date =
(select min(invoice_date) from invoices where vendor_id=i.vendor_id group by vendor_id) ORDER BY vendor_name;

