select vendor_id, SUM(invoice_total) from invoices GROUP BY vendor_id;

select vendor_name,SUM(payment_total) from invoices join vendors on invoices.vendor_id=vendors.vendor_id
GROUP BY vendors.vendor_id ORDER BY SUM(payment_total);

select vendor_name,COUNT(invoices.vendor_id), SUM(invoice_total) from invoices LEFT JOIN vendors on invoices.vendor_id=vendors.vendor_id
GROUP BY invoices.vendor_id;

select account_description, COUNT(invoice_line_items.account_number),sum(line_item_amount) from invoice_line_items LEFT JOIN general_ledger_accounts
on invoice_line_items.account_number=general_ledger_accounts.account_number GROUP BY general_ledger_accounts.account_description
HAVING COUNT(invoice_line_items.account_number)>1 ORDER BY sum(line_item_amount) DESC;

select account_description, COUNT(invoice_line_items.account_number),sum(line_item_amount) from invoice_line_items LEFT JOIN general_ledger_accounts
on invoice_line_items.account_number=general_ledger_accounts.account_number 
JOIN invoices on invoice_line_items.invoice_id=invoices.invoice_id
where invoices.invoice_date BETWEEN '2018-04-01' and '2018-06-30'
GROUP BY general_ledger_accounts.account_description
HAVING COUNT(invoice_line_items.account_number)>1 ORDER BY sum(line_item_amount) DESC;

select IFNULL(account_number,'amount'), SUM(line_item_amount) from invoice_line_items GROUP BY account_number WITH ROLLUP;

select vendor_name,count(DISTINCT invoice_line_items.account_number)
from vendors join invoices on vendors.vendor_id=invoices.vendor_id
join invoice_line_items on invoice_line_items.invoice_id=invoices.invoice_id
GROUP BY invoices.invoice_id
HAVING count(DISTINCT invoice_line_items.account_number)>1;

select if(grouping(terms_id)=1,'grand total',terms_id) as terms_id,
if(grouping(vendor_id)=1,'terms_total',vendor_id) as vendor_id,
MAX(payment_date),SUM(invoice_total-credit_total-payment_total)
from invoices GROUP BY terms_id, vendor_id WITH ROLLUP;

-- SELECT IF(GROUPING(terms_id) = 1, 'Grand Totals', terms_id) AS terms_id,
--        IF(GROUPING(vendor_id) = 1, 'Terms ID Totals', vendor_id) AS vendor_id,
--        MAX(payment_date) AS max_payment_date,
--        SUM(invoice_total - credit_total - payment_total) AS balance_due
-- FROM invoices
-- GROUP BY terms_id, vendor_id WITH ROLLUP;
