#create index vender_zip_index on vendors(vendor_zip_code);

