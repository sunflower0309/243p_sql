#ALTER TABLE members ADD annual_dues   DECIMAL(5,2)    DEFAULT 52.50 ,Add payment_date  DATE;

#alter table committees modify committee_name VARCHAR(50) NOT NULL UNIQUE;

INSERT into committees VALUES(DEFAULT,'No.2');