-- INSERT INTO members VALUES(DEFAULT,'Obama','Obama','1024 Street','Los Angles','CA','123456'),
-- (DEFAULT,'Trump','Trump','2048 Street','Berkely','CA','123456789');

-- INSERT INTO committees VALUES (DEFAULT, 'No.1'),(DEFAULT, 'No.2');

-- INSERT INTO members_committees VALUES (1,2),(2,1),(2,2);

SELECT c.committee_name, m.last_name, m.first_name
FROM committees c JOIN members_committees mc ON c.committee_id = mc.committee_id
JOIN members m ON mc.member_id = m.member_id
ORDER BY c.committee_name, m.last_name, m.first_name;