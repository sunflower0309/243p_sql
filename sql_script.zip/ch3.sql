SELECT vendor_name, vendor_contact_last_name, vendor_contact_first_name from vendors ORDER BY vendor_contact_last_name;

SELECT vendor_name, vendor_contact_last_name, vendor_contact_first_name from vendors ORDER BY vendor_contact_first_name;

select CONCAT(vendor_contact_last_name,' ,',vendor_contact_first_name) as full_name from vendors 
where vendor_contact_last_name like 'A%' or vendor_contact_last_name like 'B%'
or vendor_contact_last_name like 'C%' or vendor_contact_last_name like 'E%'
ORDER BY vendor_contact_last_name DESC;

select invoice_due_date as due_date, invoice_total as invoice_total, 0.1*invoice_total
as 10per, invoice_total*1.1 as plus_10per 
from invoices
where invoice_total>=500 and invoice_total<=1000
ORDER BY invoice_due_date DESC;

select invoice_number, invoice_total, payment_total+credit_total as payment_credit_total,
invoice_total-payment_total-credit_total as balance_due from invoices
where invoice_total-payment_total-credit_total>50
ORDER BY balance_due DESC
LIMIT 5;

select invoice_number, invoice_date, 
invoice_total-payment_total-credit_total as balance_due ,payment_date from invoices
where payment_date is NULL;

SELECT DATE_FORMAT(CURRENT_DATE(),'%m-%d-%Y') as 'current_date';

select 50000 as starting_principal, 50000*0.065 as interest, 50000*(1+0.065) as principal_plus_interest;